package com.example.countries

import android.graphics.Region

data class Country(val capital:String, val code: String, val name: String, val region: String)
